
import java.util.*;

/**
 * 
 */
public class Cliente {

    /**
     * Default constructor
     */
    public Cliente() {
    }

    /**
     * 
     */
    public String codigo;

    /**
     * 
     */
    public String nombre;

    /**
     * 
     */
    public string dni;

    /**
     * 
     */
    public string direccion;

    /**
     * 
     */
    public string telef;

}