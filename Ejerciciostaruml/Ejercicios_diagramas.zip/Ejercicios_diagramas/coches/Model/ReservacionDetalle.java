
import java.util.*;

/**
 * 
 */
public class ReservacionDetalle {

    /**
     * Default constructor
     */
    public ReservacionDetalle() {
    }

    /**
     * 
     */
    public date fechainicio;

    /**
     * 
     */
    public date fechafinal;

    /**
     * 
     */
    public int gasolina;

}