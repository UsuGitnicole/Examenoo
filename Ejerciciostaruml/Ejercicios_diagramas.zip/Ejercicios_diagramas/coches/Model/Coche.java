
import java.util.*;

/**
 * 
 */
public class Coche {

    /**
     * Default constructor
     */
    public Coche() {
    }

    /**
     * 
     */
    public double precio;

    /**
     * 
     */
    public boolean cochedisponible;

    /**
     * 
     */
    public String matricula;

    /**
     * 
     */
    public String marca;

    /**
     * 
     */
    public String modelo;

    /**
     * 
     */
    public String color;

}