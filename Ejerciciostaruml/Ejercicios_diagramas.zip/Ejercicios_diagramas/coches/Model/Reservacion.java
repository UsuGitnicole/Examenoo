
import java.util.*;

/**
 * 
 */
public class Reservacion {

    /**
     * Default constructor
     */
    public Reservacion() {
    }

    /**
     * 
     */
    public void preciototal;

}