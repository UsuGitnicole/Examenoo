
import java.util.*;

/**
 * 
 */
public class Garaje {

    /**
     * Default constructor
     */
    public Garaje() {
    }

    /**
     * 
     */
    public String codigo;

    /**
     * 
     */
    public Integer cantida_max;

}