
import java.util.*;

/**
 * 
 */
public class Almacen {

    /**
     * Default constructor
     */
    public Almacen() {
    }

    /**
     * 
     */
    public int codigo;

    /**
     * 
     */
    public String direccion;

}