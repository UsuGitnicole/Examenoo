
import java.util.*;

/**
 * 
 */
public class Empresa_Condorcito {

    /**
     * Default constructor
     */
    public Empresa_Condorcito() {
    }

    /**
     * 
     */
    public void Attribute1;

}