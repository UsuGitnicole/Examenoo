
import java.util.*;

/**
 * 
 */
public class Blanco {

    /**
     * Default constructor
     */
    public Blanco() {
    }

    /**
     * 
     */
    public void P_mercaderia;

    /**
     * 
     */
    public void T_transporte;

}