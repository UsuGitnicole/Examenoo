
import java.util.*;

/**
 * 
 */
public class Mercaderias extends Pais {

    /**
     * Default constructor
     */
    public Mercaderias() {
    }

    /**
     * 
     */
    public int codigo;

    /**
     * 
     */
    public String nombre;

    /**
     * @param codigo 
     * @param nombre 
     * @return
     */
    public void Mercaderias(int codigo, String nombre) {
        // TODO implement here
        return null;
    }

}