
import java.util.*;

/**
 * 
 */
public class Empresa {

    /**
     * Default constructor
     */
    public Empresa() {
    }

    /**
     * 
     */
    public void codigo;

    /**
     * 
     */
    public void nombre;

}