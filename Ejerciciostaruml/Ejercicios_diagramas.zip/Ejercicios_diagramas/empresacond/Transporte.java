
/**
 * 
 */
public enum Transporte {
    Aerea,
    Ferrea,
    Carretera
}