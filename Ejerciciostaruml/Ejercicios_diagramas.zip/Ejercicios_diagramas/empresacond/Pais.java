
import java.util.*;

/**
 * 
 */
public class Pais extends Transporte {

    /**
     * Default constructor
     */
    public Pais() {
    }

    /**
     * 
     */
    public int codigo;

    /**
     * 
     */
    public String nombre;

}