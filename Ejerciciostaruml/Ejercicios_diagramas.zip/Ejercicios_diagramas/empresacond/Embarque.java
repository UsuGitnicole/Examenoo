
import java.util.*;

/**
 * 
 */
public class Embarque extends Almacen {

    /**
     * Default constructor
     */
    public Embarque() {
    }

    /**
     * 
     */
    public int numero;

    /**
     * 
     */
    public date fecha;

    /**
     * 
     */
    public int cantidad;

}