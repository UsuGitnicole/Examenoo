
/**
 * 
 */
public enum Enumeration1 {
}