
import java.util.*;

/**
 * 
 */
public class Sitio_web {

    /**
     * Default constructor
     */
    public Sitio_web() {
    }

    /**
     * 
     */
    public String nombre;

    /**
     * 
     */
    public String dominio;

    /**
     * @param nombre String 
     * @param dominio String 
     * @return
     */
    public void Enlace(void nombre String, void dominio String) {
        // TODO implement here
        return null;
    }

}